import { IoTDevicesDashboard } from "@/components/iot-devices-dashboard"

export default function Home() {
  return <IoTDevicesDashboard />
}
