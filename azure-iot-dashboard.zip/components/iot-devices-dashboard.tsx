"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Menu, Bike, Users, MapPin, AlertTriangle, TrendingUp, Battery, AlertCircle, MessageSquare } from "lucide-react"

// Mock data for charts
const dailyActiveRidersData = [
  { date: "Jan 1", riders: 245 },
  { date: "Jan 2", riders: 312 },
  { date: "Jan 3", riders: 289 },
  { date: "Jan 4", riders: 356 },
  { date: "Jan 5", riders: 423 },
  { date: "Jan 6", riders: 398 },
  { date: "Jan 7", riders: 445 },
  { date: "Jan 8", riders: 467 },
  { date: "Jan 9", riders: 389 },
  { date: "Jan 10", riders: 412 },
  { date: "Jan 11", riders: 456 },
  { date: "Jan 12", riders: 478 },
  { date: "Jan 13", riders: 501 },
  { date: "Jan 14", riders: 523 },
  { date: "Jan 15", riders: 489 },
  { date: "Jan 16", riders: 445 },
  { date: "Jan 17", riders: 467 },
  { date: "Jan 18", riders: 512 },
  { date: "Jan 19", riders: 534 },
  { date: "Jan 20", riders: 556 },
  { date: "Jan 21", riders: 578 },
  { date: "Jan 22", riders: 601 },
  { date: "Jan 23", riders: 589 },
  { date: "Jan 24", riders: 612 },
  { date: "Jan 25", riders: 634 },
  { date: "Jan 26", riders: 656 },
  { date: "Jan 27", riders: 678 },
  { date: "Jan 28", riders: 645 },
  { date: "Jan 29", riders: 623 },
  { date: "Jan 30", riders: 601 },
]

const dailyDisabledBikesData = [
  { date: "Jan 1", disabled: 12 },
  { date: "Jan 2", disabled: 8 },
  { date: "Jan 3", disabled: 15 },
  { date: "Jan 4", disabled: 6 },
  { date: "Jan 5", disabled: 9 },
  { date: "Jan 6", disabled: 11 },
  { date: "Jan 7", disabled: 7 },
  { date: "Jan 8", disabled: 13 },
  { date: "Jan 9", disabled: 10 },
  { date: "Jan 10", disabled: 14 },
  { date: "Jan 11", disabled: 8 },
  { date: "Jan 12", disabled: 5 },
  { date: "Jan 13", disabled: 12 },
  { date: "Jan 14", disabled: 9 },
  { date: "Jan 15", disabled: 16 },
  { date: "Jan 16", disabled: 11 },
  { date: "Jan 17", disabled: 7 },
  { date: "Jan 18", disabled: 13 },
  { date: "Jan 19", disabled: 10 },
  { date: "Jan 20", disabled: 8 },
  { date: "Jan 21", disabled: 14 },
  { date: "Jan 22", disabled: 6 },
  { date: "Jan 23", disabled: 11 },
  { date: "Jan 24", disabled: 9 },
  { date: "Jan 25", disabled: 15 },
  { date: "Jan 26", disabled: 12 },
  { date: "Jan 27", disabled: 8 },
  { date: "Jan 28", disabled: 10 },
  { date: "Jan 29", disabled: 13 },
  { date: "Jan 30", disabled: 7 },
]

const issuesData = [
  { issue: "Low battery", count: 23 },
  { issue: "Outside service area", count: 8 },
  { issue: "Customer reported issue", count: 12 },
]

// Generate random bike positions for Redmond, WA area
const generateBikePositions = () => {
  const bikes = []
  const redmondCenter = { lat: 47.674, lng: -122.1215 }

  for (let i = 0; i < 100; i++) {
    const latOffset = (Math.random() - 0.5) * 0.02
    const lngOffset = (Math.random() - 0.5) * 0.02
    const statusRandom = Math.random()

    let status: "active" | "parked" | "disabled"
    if (statusRandom < 0.6) status = "active"
    else if (statusRandom < 0.85) status = "parked"
    else status = "disabled"

    bikes.push({
      id: i + 1,
      lat: redmondCenter.lat + latOffset,
      lng: redmondCenter.lng + lngOffset,
      status,
    })
  }

  return bikes
}

export function IoTDevicesDashboard() {
  const [selectedDevice, setSelectedDevice] = useState("e-bikes")
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const bikes = generateBikePositions()

  const activeBikes = bikes.filter((bike) => bike.status === "active").length
  const parkedBikes = bikes.filter((bike) => bike.status === "parked").length
  const disabledBikes = bikes.filter((bike) => bike.status === "disabled").length
  const utilizationRate = Math.round((activeBikes / bikes.length) * 100)

  return (
    <div className="min-h-screen bg-background">
      {/* Azure Portal Header */}
      <header className="bg-primary text-primary-foreground border-b border-border">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="text-primary-foreground hover:bg-primary/20"
            >
              <Menu className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-semibold">Azure Monitor</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm">Redmond Operations</span>
            <div className="w-8 h-8 bg-primary-foreground/20 rounded-full flex items-center justify-center">
              <span className="text-xs font-medium">PM</span>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`bg-sidebar border-r border-sidebar-border transition-all duration-300 ${
            sidebarOpen ? "w-64" : "w-16"
          }`}
        >
          <nav className="p-4">
            <div className="space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 bg-sidebar-accent text-sidebar-accent-foreground"
              >
                <Bike className="h-5 w-5" />
                {sidebarOpen && <span>IoT Devices</span>}
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 text-sidebar-foreground hover:bg-sidebar-accent/50"
              >
                <TrendingUp className="h-5 w-5" />
                {sidebarOpen && <span>Analytics</span>}
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 text-sidebar-foreground hover:bg-sidebar-accent/50"
              >
                <AlertTriangle className="h-5 w-5" />
                {sidebarOpen && <span>Alerts</span>}
              </Button>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Page Header */}
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-foreground mb-2">IoT Devices</h2>
            <p className="text-muted-foreground">Monitor and manage your connected device fleet</p>
          </div>

          {/* Device Type Selector */}
          <div className="mb-6">
            <Select value={selectedDevice} onValueChange={setSelectedDevice}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Select device type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="e-bikes">E-Bikes</SelectItem>
                <SelectItem value="scooters">Scooters</SelectItem>
                <SelectItem value="cars">Cars</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Summary Tiles */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Riders</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-chart-1">{activeBikes}</div>
                <p className="text-xs text-muted-foreground">+12% from yesterday</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Parked Bikes</CardTitle>
                <MapPin className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-chart-4">{parkedBikes}</div>
                <p className="text-xs text-muted-foreground">Available for use</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Disabled Bikes</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-destructive">{disabledBikes}</div>
                <p className="text-xs text-muted-foreground">Require maintenance</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Utilization Rate</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-chart-3">{utilizationRate}%</div>
                <p className="text-xs text-muted-foreground">Fleet efficiency</p>
              </CardContent>
            </Card>
          </div>

          {/* Map Section */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Redmond, Washington - Fleet Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative bg-muted rounded-lg h-96 overflow-hidden">
                {/* Simplified map representation */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-green-50">
                  <div className="absolute top-4 left-4 flex gap-4">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-chart-1 rounded-full"></div>
                      <span className="text-xs">Active ({activeBikes})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-chart-4 rounded-full"></div>
                      <span className="text-xs">Parked ({parkedBikes})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-destructive rounded-full"></div>
                      <span className="text-xs">Disabled ({disabledBikes})</span>
                    </div>
                  </div>

                  {/* Bike markers */}
                  {bikes.map((bike) => (
                    <div
                      key={bike.id}
                      className={`absolute w-2 h-2 rounded-full ${
                        bike.status === "active"
                          ? "bg-chart-1"
                          : bike.status === "parked"
                            ? "bg-chart-4"
                            : "bg-destructive"
                      }`}
                      style={{
                        left: `${((bike.lng + 122.1215) / 0.02) * 100}%`,
                        top: `${((47.674 - bike.lat) / 0.02) * 100}%`,
                      }}
                    />
                  ))}

                  {/* City label */}
                  <div className="absolute bottom-4 right-4 bg-white/90 px-3 py-1 rounded text-sm font-medium">
                    Redmond, WA
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Daily Active Riders</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={dailyActiveRidersData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="riders" stroke="hsl(var(--chart-1))" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Daily Disabled Bikes</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={dailyDisabledBikesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="disabled" stroke="hsl(var(--destructive))" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Issues Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                Active Issues
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Issue Type</TableHead>
                    <TableHead>Count</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {issuesData.map((issue, index) => (
                    <TableRow key={index}>
                      <TableCell className="flex items-center gap-2">
                        {issue.issue === "Low battery" && <Battery className="h-4 w-4 text-destructive" />}
                        {issue.issue === "Outside service area" && <MapPin className="h-4 w-4 text-chart-4" />}
                        {issue.issue === "Customer reported issue" && (
                          <MessageSquare className="h-4 w-4 text-chart-3" />
                        )}
                        {issue.issue}
                      </TableCell>
                      <TableCell>
                        <Badge variant={issue.count > 15 ? "destructive" : "secondary"}>{issue.count}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{issue.count > 15 ? "High Priority" : "Normal"}</Badge>
                      </TableCell>
                      <TableCell>
                        <Button size="sm" variant="outline">
                          View Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}
